public class Main {
    public static void main(String[] args) {
        int numeroIf = 10;

        if (numeroIf > 5){
            System.out.println("El número es positivo");
        } else if (numeroIf < 0) {
            System.out.println("El numero es negativo");
        } else if(numeroIf == 0) {
            System.out.println("El numero es cero");
        }
    }
}