public class Main {
    public static void main(String[] args) {
        var estacion = "Primavera";


        switch (estacion){
            case "Invierno":
                System.out.println("Es invierno!");
                break;
            case "Primavera":
                System.out.println("Es primavera!");
                break;
            case "Verano":
                System.out.println("Es verano"!);
                break;
            case "Otoñio":
                System.out.println("Es otoñio!");
                break;
            default:
                System.out.println("Estoy en default");
        }

    }
}