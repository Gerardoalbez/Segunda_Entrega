public class Main {
    public static void main(String[] args) {
        for (int numeroFor = 0; numeroFor <= 3; numeroFor = numeroFor + 1)
        System.out.println(numeroFor);
    }
}